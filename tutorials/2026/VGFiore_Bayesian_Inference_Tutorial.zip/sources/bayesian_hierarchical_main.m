clear 
% close all

% data_folder='par4'; par=4; 
% data_folder='par5'; par=5; 
% data_folder='par6'; par=6; 
% data_folder='par7'; par=7; 
% data_folder='par8'; par=8; 
data_folder='par9'; par=9; 

save_name=['fish_optimization_H_par', num2str(par)];
root_folder = '.';
addpath(root_folder)

cd (data_folder)

subdirs = dir('fish*');
n_subjects=length(subdirs);
n_iter=1000;                                                  

n_fish=3;
n_trials=15;
start_trial=1;
n_blocks=10;
tau=.1;      

par_names{1}='likelihood_normal_distribution';
prmtn=length(par_names);
par_names{2}='Dirichlet_weight_update';
prmtn=length(par_names);

%% get subject list
for i=1:n_subjects 
    subj{i,1} = subdirs(i).name;
    likely1{i}=zeros(n_iter,n_blocks);
    likely2{i}=zeros(n_iter,n_blocks);
end

best_set=zeros(n_subjects,prmtn*2+2);

tic
for agent=1:n_subjects
    clear data
    clear cond2
    disp(agent);
    toc
    %load data series per each agent
    load(subj{agent})

    %load real choice selections
    all_data{agent,1}=data;

    for iter=1:n_iter
        
        choice_selections=0;
        
        errors=zeros(n_iter,n_blocks);
        parameters{agent}(iter,1)=rand(1)*2/3+1/3;
        lambda1=parameters{agent}(iter,1);
        parameters{agent}(iter,2)=rand(1)/2;
        k=parameters{agent}(iter,2);

        m=lambda1;
        s=(1-lambda1)/2;
        fishp=[0 1 1
               1 0 1
               1 1 0]*s + eye(3)*m;
    

        for blocki=1:n_blocks
            clear fish_disp
            clear real_choices
            
            alpha0=fishp*10;  %transforms initial probabilities into a fictitious alpha0 sequence of 10 trials
            dirch_upd=zeros(3);

            pondp{blocki}=ones(n_trials,n_fish)/n_fish;
            fish_disp=all_data{agent}{blocki}(:,4);
            real_choices=all_data{agent}{blocki}(:,1);

            for triali=start_trial:length(fish_disp)
                
                if triali==start_trial
                    prob=pondp{blocki}(triali,:);
                else
                    prob=pondp{blocki}(triali-1,:);

                    %update of Dirichlet distribution, based on evidence
                    % dirch_upd=zeros(3); dirch_upd(:,fish_disp(triali-1))=1;    
                    % fishp=fishp+k*dirch_upd; % the perceived evidence 
                    % fishp=fishp ./ sum(fishp, 2); %normalise by row
                    % end

                end
                %update of Dirichlet distribution, based on evidence
                dirch_upd(:,1)=sum(fish_disp(1:triali)==1);
                dirch_upd(:,2)=sum(fish_disp(1:triali)==2);
                dirch_upd(:,3)=sum(fish_disp(1:triali)==3);

                fishp=alpha0+k*dirch_upd; % the perceived evidence
                fishp=fishp ./ sum(fishp, 2); %normalise by row

                %Bayesian update
                den=sum(prob.*fishp(fish_disp(triali),:));
                pondp{blocki}(triali,:)=(fishp(fish_disp(triali),:).*prob)/den;

                distro=pondp{blocki}(triali,:);
                
                pondp{blocki}(triali,:)=max(0.05, pondp{blocki}(triali,:));
                pondp{blocki}(triali,:)=pondp{blocki}(triali,:)/sum(pondp{blocki}(triali,:));


                %comparison
                if real_choices(triali)>0
                    choice_selections=choice_selections+1;

                    errors(iter,blocki)= 1-distro(real_choices(triali));
                    likely1{agent}(iter,blocki)=likely1{agent}(iter,blocki)+ errors(iter,blocki);
                    likely2{agent}(iter,blocki)=likely2{agent}(iter,blocki)+ min(2, abs(log(distro(real_choices(triali)))));                    
                    % likely2{agent}(iter,blocki)=likely2{agent}(iter,blocki)+ min(5, abs(log(distro(real_choices(triali)))));
                end

                if max(pondp{blocki}(triali,:))==0.05
                    error ('check')
                end

            end
        end
    end
    sum_likely1{agent}=sum(likely1{agent},2);
    sum_likely2{agent}=sum(likely2{agent},2);
    [val1, pos1]=min(sum_likely1{agent});
    [val2, pos2]=min(sum_likely2{agent});
    
    best_set(agent,1:prmtn)=parameters{agent}(pos1,:);
    best_set(agent,prmtn+1)=val1*100/choice_selections;
    best_set(agent,(prmtn+2):(prmtn*2+1))=parameters{agent}(pos2,:);
    best_set(agent,prmtn*2+2)=val2;
    
    disp(best_set(agent,:));
    % cd(root_folder)
    % save('partial_fish_optimization', 'best_set');
end

mean_bs=mean(best_set(1:n_subjects,:))
std_bs=std(best_set(1:n_subjects,:))

cd (root_folder)

save(save_name, 'best_set', 'mean_bs', 'std_bs', 'par_names', 'all_data');

figure
scatter(ones(length(best_set(:,1)),1),best_set(:,1))
hold on
scatter(ones(length(best_set(:,1)),1)+1,best_set(:,3))
axis([0 3 0 1.1])
