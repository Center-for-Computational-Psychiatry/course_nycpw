# Copyright (C) 2025 Blair Shevlin <blairshevlin@gmail.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

rm(list = ls())

libs = c("runjags","tidyverse","purrr","DEoptim","Rcpp","parallel","RcppParallel","loo","coda",
        "ggpubr","fs","here","rtdists")

suppressPackageStartupMessages(lapply(libs, require, character.only = TRUE))
RcppParallel::setThreadOptions(numThreads = 1)

# Custom function for calculating standard error
se = function(x) sd(x) / sqrt(length(x))

# Random seed for reporducability
b_seed = 10051990
set.seed(b_seed)

# paths (feel free to change)
dir = path(here()) # where this R project is located
model_path = dir / "src" 
output_path = dir / "results"

# Load data
# ???

# create data!

# boundary separation
alpha.mu = 1.25
# non-decision time
tau.mu = 0.3
# drift rate
delta.mu = 0.3
# starting point
beta.mu = 0.5

# number of simulated trials
nTrials = 400

simulation = rdiffusion(n = nTrials, # number of trials to simulate
                     a = alpha.mu,  # boundary separation
                     t0 = tau.mu, # non-decision time
                     z = alpha.mu * beta.mu, # starting point
                     v = delta.mu # drift rate
                     ) 

head(simulation)

ggplot(simulation, aes(x = rt, color = response))+
    theme_pubr(base_size = 18) +
    geom_density() +
    labs(x = "Response time (sec)",
         y = "Density",
         color = "Response")

# Convert to JAGS-compatible format

# Code response times as positive when upper boundary is hit, negative otherwise
reaction_times = simulation$rt
response = which(simulation$response=="lower")
reaction_times[response] = reaction_times[response] * -1

# convert to list format
data_list <- list(y = reaction_times, 
                  N = length(reaction_times))

# what variables to monitor
monitor = c("deviance","alpha", "tau", "beta", "delta")
### include "log_lik" when doing model comparisons

# Start each chain with a unique starting point
inits3 <- dump.format(list( alpha=3, 
                            tau=0.2,
                            delta=0.3,
                            beta=0.4, 
                            y_pred=reaction_times,  .RNG.name="base::Super-Duper", .RNG.seed=99999))

inits2 <- dump.format(list( alpha=2, 
                            tau=0.1,
                            delta=0.4,
                            beta=0.6,  
                            y_pred=reaction_times,  .RNG.name="base::Wichmann-Hill", .RNG.seed=1234))

inits1 <- dump.format(list( alpha=1, 
                            tau=0.15,
                            delta=0.2,
                            beta=0.5,  
                            y_pred=reaction_times, .RNG.name="base::Mersenne-Twister", .RNG.seed=6666 ))


# Run model
results <- run.jags(model=file.path(model_path,"example_model.txt"), 
                    monitor=monitor, 
                    data=data_list, 
                    n.chains=3, 
                    inits=c(inits1,inits2, inits3), 
                    plots = TRUE, 
                    method="parallel", module="wiener", 
                    # How many samples are discarded
                    burnin=1000, 
                    # Actualy number of samples
                    sample=5000, 
                    # Reduces auto-correlations
                    thin=1)
#save(results, file = output_path / "example_fit.RDA")
load(file = output_path / "example_fit.RDA")

# Extract MCMC samples from runjags object
mcmc_samples <- as.mcmc.list(results$mcmc)

# Create summary tables
sum_samples <- summary(results)

# 1. Trace plots for each parameter
traceplot(mcmc_samples)
### Smooshed caterpillars are good

# 2. Autocorrelation plots
autocorr.plot(mcmc_samples)
### smaller values are good

# 3. Gelman-Rubin Diagnostic (R-hat)

sum_samples %>% as.data.frame()

gelman.diag(mcmc_samples)
gelman.plot(mcmc_samples)
### values < 1.1 are good

# 4. Effective Sample Size (ESS)

sum_samples %>% as.data.frame()

effective_size <- effectiveSize(mcmc_samples)
print(effective_size)
### > 200 per parameter is good

# 5. Summary statistics for the chains
summary(mcmc_samples)
# alpha = 1.25
# tau = 0.3
# beta = 0.5
# delta = 0.3

# 6. Densities of posterior distributions for the parameters
# Use ggplot2 to visualize posterior densities
param_names <- c("alpha", "tau", "beta", "delta")
samples_df <- as.data.frame(as.matrix(mcmc_samples))

samples_df_long <- samples_df %>%
  pivot_longer(cols = all_of(param_names), names_to = "parameter", values_to = "value")

# True parameter values from your simulation
true_values <- data.frame(
  parameter = c("alpha", "tau", "beta", "delta"),
  true_value = c(alpha.mu, tau.mu, beta.mu, delta.mu)
)

# Calculate 95% credible intervals for each parameter
credible_intervals <- samples_df_long %>%
  group_by(parameter) %>%
  summarize(lower = quantile(value, probs = 0.025),
            upper = quantile(value, probs = 0.975))

# Merge credible intervals with true values
credible_intervals <- credible_intervals %>%
  left_join(true_values, by = "parameter")

# Plot with vertical lines for true values
ggplot(samples_df_long, aes(x = value, fill = parameter)) +
  geom_density(alpha = 0.2) +
  facet_wrap(~parameter, scales = "free") +
  theme_pubr() +
  labs(title = "Posterior Distributions", x = "Parameter Value", y = "Density") +
  # Vertical dashed lines for true values
  geom_vline(data = true_values, aes(xintercept = true_value, color = parameter),
             linetype = "dashed", size = 1) +
  # Horizontal bar for 95% credible intervals
  geom_segment(data = credible_intervals, aes(x = lower, xend = upper, y = 0, yend = 0, color = parameter),
               size = 1.5) +
  # Shift the bar slightly below the density curve
  geom_point(data = credible_intervals, aes(x = lower, y = 0, color = parameter), size = 2) + 
  geom_point(data = credible_intervals, aes(x = upper, y = 0, color = parameter), size = 2) +
  # Ensure colors are consistent
  scale_color_manual(values = c("alpha" = "blue", "tau" = "green", "beta" = "red", "delta" = "purple"))+
  scale_fill_manual(values = c("alpha" = "blue", "tau" = "green", "beta" = "red", "delta" = "purple"))

# 7. Gelman plot (displays shrinkage factor over iterations)
gelman.plot(mcmc_samples)

# 8. Additional diagnostic plots (if needed)
plot(results)
