clear
close all

% load('fish_population_par4')
% load('fish_population_par5')
% load('fish_population_par6')
% load('fish_population_par7')
% load('fish_population_par8')
load('fish_population_par9')
addpath('.')
load('behavioral_sequence.mat')

n_trials=15;
n_blocks=10;
fish_disp=behavioral_sequence.fish;

for blocki=1:n_blocks
for j=1:n_trials

    choice1{blocki}(j)=sum(choices_block_redux{blocki}(:,j)==1);
    choice2{blocki}(j)=sum(choices_block_redux{blocki}(:,j)==2);
    choice3{blocki}(j)=sum(choices_block_redux{blocki}(:,j)==3);
    real_choises_perc{1,blocki}(j)=choice1{blocki}(j)*100/(choice1{blocki}(j)+choice2{blocki}(j)+choice3{blocki}(j));
    real_choises_perc{2,blocki}(j)=choice2{blocki}(j)*100/(choice1{blocki}(j)+choice2{blocki}(j)+choice3{blocki}(j));
    real_choises_perc{3,blocki}(j)=choice3{blocki}(j)*100/(choice1{blocki}(j)+choice2{blocki}(j)+choice3{blocki}(j));

    
end
end

for blocki=1:n_blocks
c1=0;
c2=0;
c3=0;
for bi=1:n_trials
    if fish_disp{blocki}(1,bi)==1
        c1=c1+1;
        fish_order{blocki,1}(c1)=bi;
    elseif fish_disp{blocki}(1,bi)==2
        c2=c2+1;
        fish_order{blocki,2}(c2)=bi;
    elseif fish_disp{blocki}(1,bi)==3
        c3=c3+1;
        fish_order{blocki,3}(c3)=bi;
    end
end
end



%%%%%%%%%%%%%%%PLOT%%%%%%%%%%%%%%%%%%%

col1=[0.5 0.5 0.9];
col2=[1.0 0.8 0.2];
col3=[0.2 0.8 0.3];
% col1=[0.8 0.3 0.2];
% col2=[0.2 0.8 0.3];
% col3=[0.2 0.3 0.8];
lin_w=3;
t1=0.5;
t2=t1;
t3=t1;


for blocki=1:n_blocks
h=figure;
screen_size=get(0,'ScreenSize');
screen_size(1:2)=screen_size(3:4)*1/10;
screen_size(3:4)=[1200  600];
set(h,'Position',screen_size)

subplot(2,1,1)
hold on
scatter(fish_order{blocki,1}, ones(length(fish_order{blocki,1}),1)*1.1, 100, 'LineWidth', 1, 'MarkerEdgeColor', [0 0 0], 'MarkerFaceColor', col1) %'flat'
scatter(fish_order{blocki,2}, ones(length(fish_order{blocki,2}),1)*1.1, 100, 'LineWidth', 1, 'MarkerEdgeColor', [0 0 0], 'MarkerFaceColor', col2) %'flat'
scatter(fish_order{blocki,3}, ones(length(fish_order{blocki,3}),1)*1.1, 100, 'LineWidth', 1, 'MarkerEdgeColor', [0 0 0], 'MarkerFaceColor', col3) %'flat'
plot(1:n_trials,real_choises_perc{1,blocki}/100, 'LineWidth', lin_w, 'Color', col1);
plot(1:n_trials,real_choises_perc{2,blocki}/100, 'LineWidth', lin_w, 'Color', col2);
plot(1:n_trials,real_choises_perc{3,blocki}/100, 'LineWidth', lin_w, 'Color', col3);
hold off
set(gca,'FontName','Arial','FontSize',12,'FontWeight','Bold',  'LineWidth', 2);
set(gca,'YTick',0:0.2:1, 'YTickLabel',{'0%', '20%', '40%', '60%', '80%', '100%'}, 'FontWeight','bold', 'FontSize',14)
title('Pond selections', 'FontSize',14)
axis([1 n_trials -0.05 1.15])

subplot(2,1,2)
hold on
scatter(fish_order{blocki,1}, ones(length(fish_order{blocki,1}),1)*1.2, 100, 'LineWidth', 1, 'MarkerEdgeColor', [0 0 0], 'MarkerFaceColor', col1) %'flat'
scatter(fish_order{blocki,2}, ones(length(fish_order{blocki,2}),1)*1.2, 100, 'LineWidth', 1, 'MarkerEdgeColor', [0 0 0], 'MarkerFaceColor', col2) %'flat'
scatter(fish_order{blocki,3}, ones(length(fish_order{blocki,3}),1)*1.2, 100, 'LineWidth', 1, 'MarkerEdgeColor', [0 0 0], 'MarkerFaceColor', col3) %'flat'
filled_plot_recursive_no0(conf1{blocki}*0.999, col1, 2, 0.3);
filled_plot_recursive_no0(conf2{blocki}*0.999, col2, 2, 0.3);
filled_plot_recursive_no0(conf3{blocki}*0.999, col3, 2, 0.3);
hold off
set(gca,'FontName','Arial','FontSize',12,'FontWeight','Bold',  'LineWidth', 2);
set(gca,'YTick',0:0.2:1, 'YTickLabel',0:0.2:1, 'FontWeight','bold', 'FontSize',14)
title('Model-estimated confidence in the three choices', 'FontSize',14)
axis([1 n_trials -0.05 1.25])
end
