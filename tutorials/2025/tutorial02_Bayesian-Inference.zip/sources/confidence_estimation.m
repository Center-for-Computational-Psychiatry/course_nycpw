clear all
close all

%time marks
% behavioral_sequence.fish -> sequences of caught fish (10 blocks, 15 trials each)
% behavioral_sequence.ponds -> ponds in which the fish is caught (10 blocks, 15 trials each)


root_folder = '.';
load('behavioral_sequence.mat')
load('fish_optimization_O_par8.mat')

n_subjects=length(best_set(:,1));

n_fish=3;
n_trials=15;
start_trial=1;
n_blocks=10;
tau=.1;

par_names{1}='likelihood_normal_distribution';
prmtn=length(par_names);

tic
for agent=1:n_subjects

    disp(agent);
    tot_valid_trials(agent)=0;
    toc
    %load data series per each agent

    lambda1=best_set(agent,3);

    m=lambda1;
    s=(1-lambda1)/2;

    fishp=[0 1 1
        1 0 1
        1 1 0]*s + eye(3)*m;

    for blocki=1:n_blocks %
        clear real_choices
        clear fish_disp
        pondp{blocki}=ones(n_trials,n_fish)/n_fish;

        valid_trials=0;
        fish_disp=all_data{agent}{blocki}(:,4);
        real_choices=all_data{agent}{blocki}(:,1);
        choices_block_redux{blocki}(agent,:)=real_choices;
        fish_disp_redux{blocki}(agent,:)=fish_disp;

        for triali=start_trial:length(fish_disp)

            if triali==start_trial
                prob=pondp{blocki}(triali,:);
            else
                prob=pondp{blocki}(triali-1,:);
            end
            %Bayesian update
            den=sum(prob.*fishp(fish_disp(triali),:));

            pondp{blocki}(triali,:)=(fishp(fish_disp(triali),:).*prob)/den;
            distro=pondp{blocki}(triali,:);
            pondp{blocki}(triali,:)=max(0.05, pondp{blocki}(triali,:));
            pondp{blocki}(triali,:)=pondp{blocki}(triali,:)/sum(pondp{blocki}(triali,:));

            conf1{blocki}(agent,triali)=distro(1);
            conf2{blocki}(agent,triali)=distro(2);
            conf3{blocki}(agent,triali)=distro(3);

            choice_conf{blocki}(agent,triali)=distro(real_choices(triali));
            valid_trials=valid_trials+1;
        end

        tot_valid_trials(agent)=tot_valid_trials(agent)+valid_trials;

    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%
cd(root_folder)
save('confidence_estimation_plot',  'conf1', 'conf2', 'conf3');
