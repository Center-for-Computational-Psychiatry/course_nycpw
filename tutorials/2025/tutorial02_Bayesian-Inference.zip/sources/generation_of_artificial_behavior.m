clear 
close all

%time marks
% behavioral_sequence.fish -> sequences of caught fish (10 blocks, 15 trials each)
% behavioral_sequence.ponds -> ponds in which the fish is caught (10 blocks, 15 trials each)

data_folder = 'par9'; lambdamod=9;
% data_folder = 'par8'; lambdamod=8;
% data_folder = 'par7'; lambdamod=7;
% data_folder = 'par6'; lambdamod=6;
% data_folder = 'par5'; lambdamod=5;
% data_folder = 'par4'; lambdamod=4;
simul_name=['fish_population_par', num2str(lambdamod(end))];

load('behavioral_sequence.mat')

n_subjects=99;

n_fish=3;
n_trials=15;
start_trial=1;
n_blocks=10;

par_names{1}='likelihood_normal_distribution';
prmtn=length(par_names);

cd(data_folder)

for agent=1:n_subjects

    disp(agent);

    %generate parameter within range
    lambda1=rand(1)*0.1+(lambdamod/10);
        
    m=lambda1;    
    s=(1-lambda1)/2;
    fishp=[0 1 1
           1 0 1
           1 1 0]*s + eye(3)*m;
        
        for blocki=1:n_blocks %

            clear simul_choices
            reward(blocki,agent)=0;

            fish_disp=behavioral_sequence.fish{blocki};
            hidden_pond=behavioral_sequence.ponds{blocki};
            pondp{blocki}=ones(n_trials,n_fish)/n_fish;

            for triali=start_trial:length(fish_disp)
                
                if triali==start_trial
                    prob=pondp{blocki}(triali,:);
                else
                    prob=pondp{blocki}(triali-1,:);
                end
                %Bayesian update
                % computed denominator in Bayesian update
%                 if fish_disp(triali)==1
%                     den=prob(1)*fishp(1,1)+prob(2)*fishp(1,2)+prob(3)*fishp(1,3);
%                 elseif fish_disp(triali)==2
%                     den=prob(1)*fishp(2,1)+prob(2)*fishp(2,2)+prob(3)*fishp(2,3);
%                 elseif fish_disp(triali)==3
%                     den=prob(1)*fishp(3,1)+prob(2)*fishp(3,2)+prob(3)*fishp(3,3);
%                 end
                %the lines commented above can be summariesed as follows
                den=sum(prob.*fishp(fish_disp(triali),:)); 

                %compute bayesian update, based on perceived stimuli
                pondp{blocki}(triali,:)=(fishp(fish_disp(triali),:).*prob)/den;

                %add a minimum value for probability distribution (and normalise) to avoid the effects of over-precision
                pondp{blocki}(triali,:)=max(0.05, pondp{blocki}(triali,:));
                pondp{blocki}(triali,:)=pondp{blocki}(triali,:)/sum(pondp{blocki}(triali,:));
                
                %estimate confidence
                conf1{blocki}(agent,triali)= pondp{blocki}(triali,1);
                conf2{blocki}(agent,triali)= pondp{blocki}(triali,2);
                conf3{blocki}(agent,triali)= pondp{blocki}(triali,3);
                
                %calculate choice
                p_action=rand(1);
                if p_action<=pondp{blocki}(triali,1)
                    simul_choices(triali)=1;
                elseif p_action<=(pondp{blocki}(triali,1)+pondp{blocki}(triali,2))
                    simul_choices(triali)=2;
                elseif p_action<=1
                    simul_choices(triali)=3;
                end
                
                %build single files for simulated subjects
                single_simul_name=['fish_', num2str(agent)];
                data{blocki}(triali,1)=simul_choices(triali);                
                data{blocki}(triali,4)=fish_disp(triali);
                data{blocki}(triali,5)=hidden_pond(triali);

                %calculate_reward
                if simul_choices(triali)==hidden_pond(triali)
                    reward(blocki,agent)=reward(blocki,agent)+100;
                    data{blocki}(triali,2)=1;
                    data{blocki}(triali,3)=100;
                else
                    reward(blocki,agent)=reward(blocki,agent)+0;
                    data{blocki}(triali,2)=2;
                    data{blocki}(triali,3)=0;
                end
            end

            choices_block_redux{blocki}(agent,:)=simul_choices;
                    
        end

        save(single_simul_name, 'data')
end

%compute mean reward per parameter
mean_reward=mean(mean(reward,2));

cd ..

save(simul_name,  'conf1', 'conf2', 'conf3', 'choices_block_redux', 'behavioral_sequence', 'reward', 'mean_reward');

%%%%%%%%%%%%%%%%%%%%%%%%%


