function fig= filled_plot_recursive(input_vecs1, color_mean1, lnw, transparency1)

for triali=1:length(input_vecs1(1,:))
    no0_input_vecs1=0;
    c=1;
    for si=1:length(input_vecs1(:,1))
        if input_vecs1(si,triali)>0
            no0_input_vecs1(c)=input_vecs1(si,triali);
            c=c+1;
        end
    end
%     disp(no0_input_vecs1);
    mean_vec1(triali)=mean(no0_input_vecs1);
    % error_vec1=std(input_vecs1)/sqrt(length(input_vecs1(:,1)));
    % error_vec2=std(input_vecs2)/sqrt(length(input_vecs2(:,1)));
    % error_vec3=std(input_vecs3)/sqrt(length(input_vecs3(:,1)));
    error_vec1(triali)=std(no0_input_vecs1);
end

mean_vec1=mean_vec1;

color_error1=min(1, color_mean1+0.3);

x1=1:length(mean_vec1);
X1=[x1,fliplr(x1)];
y1=mean_vec1(1:end)+error_vec1(1:end);
y2=mean_vec1(1:end)-error_vec1(1:end);

Y1=[y1,fliplr(y2)];

hold on
fig{1}=fill(X1,Y1, color_error1, 'EdgeColor', color_error1);
fig{2}=plot(1:15,mean_vec1(1:end), 'Color',color_mean1, 'LineWidth',  lnw);

set(fig{1},'facealpha',transparency1);
hold off

end

